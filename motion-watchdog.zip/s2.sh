#!/bin/bash

mpg321 knall.mp3

exit 0

